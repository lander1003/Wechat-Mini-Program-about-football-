# coding:utf-8
from http.server import BaseHTTPRequestHandler, HTTPServer
from os import curdir, sep
import cgi
import logging
import time
import pymysql
import socket
import ssl
import datetime
import time
import json
from wsgiref.simple_server import make_server
import urllib.parse
import re
port = 8888
db=pymysql.connect("localhost","root","123456","dongqiudi")

def pingjun(a):
    num=len(a)
    sum=0
    for i in a:
        sum=sum+i
    return sum/num
host = ('localhost', 8888)
class Resquest(BaseHTTPRequestHandler):
    def do_POST(self):
        print("i am doing post")
        logging.warning(self.headers)
        form = cgi.FieldStorage(
        fp=self.rfile,
        headers=self.headers,
        environ={'REQUEST_METHOD': 'GET',
                     'CONTENT_TYPE': self.headers['Content-Type'],
                     })
        datas = self.rfile.read(int(self.headers['content-length']))
        json_str = datas.decode('utf-8') # byte 转 str
        json_dict = json.loads(json_str)
        print(json_dict)
        way=json_dict['way']
        if way=='searchplayer':
            cursor=db.cursor()
            sql='SELECT * FROM dongqiudi.player where pname like'+'\'%'+json_dict['player']+'%\''
            cursor.execute(sql)
            db.commit()
            results=cursor.fetchall()
            results=list(results)
            keys=['name','age','nation','club','position','shoot','pace','strength','defence','dribbling','pass','mindset','eva']
            finalresults=[]
            for each in results:
                each=dict(zip(keys,each))
                finalresults.append(each)
            data={'result':finalresults}
        elif way=='searchclub':
            cursor=db.cursor()
            sql='SELECT * FROM dongqiudi.player where pclub like'+'\'%'+json_dict['club']+'%\''
            cursor.execute(sql)
            db.commit()
            results=cursor.fetchall()
            results=list(results)
            keys=['name','age','nation','club','position','shoot','pace','strength','defence','dribbling','pass','mindset','eva']
            finalresults=[]
            for each in results:
                each=dict(zip(keys,each))
                finalresults.append(each)
            data={'result':finalresults}
        elif way=='newplayer':
            cursor=db.cursor()
            sql='INSERT INTO dongqiudi.player (PNAME,PAGE,PNATION,PCLUB,PPOSITION,PSHOOT,PPACE,PSTREN,PDEFEND,PDRIB,PPASS,PMIND) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            cursor.execute(sql,[json_dict['pname'],json_dict['page'],json_dict['pnation'],json_dict['pclub'],json_dict['pposition'],json_dict['pshoot'],json_dict['ppace'],json_dict['pstren'],json_dict['pdefend'],json_dict['pdrib'],json_dict['ppass'],json_dict['pmind']])
            db.commit()
            data={'result':'创建成功!'}
        elif way=="addscore":
            file=open("score.txt",'r')
            js=file.read()
            score=json.loads(js)
            file.close
            json_dict['eva']=int(json_dict['eva'])
            if json_dict['name'] in score:
                score[json_dict['name']].append(json_dict['eva'])
            else:
                score[json_dict['name']]=[json_dict['eva']]
            print(json_dict['eva'])
            print(json_dict['name'])
            eva=pingjun(score[json_dict['name']])
            print(eva)
            js=json.dumps(score)
            f=open('score.txt','w')
            f.write(js)
            f.close
            cursor=db.cursor()
            sql=('UPDATE dongqiudi.player set PEVA=%f'%eva)+ 'where PNAME='+'\''+json_dict['name']+'\''
            cursor.execute(sql)
            print(sql)
            db.commit()
            data={'result':'打分成功'}



        

#        for key in json_dict.keys():
#                value=form[key].value
#        print(value)
 #       form_str=form.decode('utf-8')
 #       form_dict=json.loads(form_str)
 #       print(form_dict)
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())


    
if __name__ == '__main__':
 #   httpd = make_server("0.0.0.0", port ,get)
    server = HTTPServer(host, Resquest)
    print("Starting server, listen at: %s:%s" % host)
   # server.socket = ssl.wrap_socket(server.socket, certfile='./https_svr_key.pem', server_side=True)
    server.serve_forever()

