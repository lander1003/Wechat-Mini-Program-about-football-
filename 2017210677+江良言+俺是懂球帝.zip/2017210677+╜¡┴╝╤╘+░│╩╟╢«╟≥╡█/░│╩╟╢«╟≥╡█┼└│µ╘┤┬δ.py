
import requests
import time
import pymysql
from bs4 import BeautifulSoup
i=0
file_name='playerlist.txt'
f=open(file_name,'r+',encoding='utf-8')
user_agent = 'Your user_agent'
headers = {'User-Agent':user_agent}
db=pymysql.connect("localhost","root","123456","dongqiudi")
cursor=db.cursor()
sql = """
    insert into dongqiudi.player (PNAME,PAGE,PNATION,PCLUB,PPOSITION,PSHOOT,PPACE,PSTREN,PDEFEND,PDRIB,PPASS,PMIND)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
"""
i=0
url = 'https://www.dongqiudi.com/data?competition=16'
html = requests.get(url=url, headers=headers)
soup = BeautifulSoup(html.text, 'lxml')
teamlist=soup.find('table',class_='list_1').find_all('a')
img_src = soup.find_all('img')[1].attrs['src']
s=0
for team in teamlist:
    print(team["href"])
#    if s<19:
#        s+=1
#        continue
    teamurl=team['href']
    html1 = requests.get(url=teamurl, headers=headers)
    soup1 = BeautifulSoup(html1.text, 'lxml')
    playerlist=soup1.find('table',class_='teammates_list').find_all('a')
    for player in playerlist:
        playerurl=player["href"]
        html2 = requests.get(url=playerurl, headers=headers)
        soup2 = BeautifulSoup(html2.text, 'lxml')
#        cn_name = soup2.h1.text
#        detail_info = soup2.find('ul',class_='detail_info').find_all('li')
#        club = detail_info[0].text.split('：')[1].strip()  # 俱乐部
        i+=1
        if img_src == 'https://static1.dongqiudi.com/web-new/web/images/icon_error.png':
            pass
        else:
            # 个人信息
            cn_name = soup2.h1.text  # 姓名
            en_name = soup2.find('span',class_='en_name').text  # 英文名
            player_img = soup2.find('img',class_='player_img').attrs['src']  # 头像地址
            detail_info = soup2.find('ul',class_='detail_info').find_all('li')

            club = detail_info[0].text.split('：')[1].strip()  # 俱乐部
            pos = detail_info[1].text.split('：')[1].strip()  # 场上位置
            num = detail_info[2].text.split('：')[1].replace('号', '').strip()  # 号码
            if num == '':
                num = 0
            else:
                num = int(num)
            country = detail_info[3].text.split('：')[1].strip()  # 国家
            if country=='':
                country="unknown"
            else:
                country=str(country)
            age = detail_info[4].text.split('：')[1].replace('岁', '')  # 年龄
            if age=='':
                age=0
            else:
                age=int(age)
            birthday = detail_info[5].text.split('：')[1]  # 出生日期
            if birthday=='':
                birthday="unknown"
            else:
                birthday=str(birthday)
            height = detail_info[6].text.split('：')[1].replace('CM', '').strip()  # 身高
            if height == '':
                height = 0
            else:
                height = float(height)
            weight = detail_info[7].text.split('：')[1].replace('KG', '').strip()  # 体重
            if weight == '':
                weight = 0
            else:
                weight = float(weight)
            foot = detail_info[8].text.split('：')[1].replace('脚', '').strip()  # 惯用脚

            # 综合能力
            score = soup2.find('div', id='title').text.replace('综合能力', '').strip()  # 综合得分
            if score == '':
                score = 50
            else:
                score = int(score)
            speed = soup2.find('div', class_='item item0').find('span').text.strip()
            if speed == '-':
                speed = 50
            else:
                speed = int(speed)
            power = soup2.find('div', class_='item item1').find('span').text.strip()
            if power == '-':
                power = 50
            else:
                power = int(power)
            defense = soup2.find('div', class_='item item2').find('span').text.strip()
            if defense == '-':
                defense = 50
            else:
                defense = int(defense)
            dribble = soup2.find('div', class_='item item3').find('span').text.strip()
            if dribble == '-':
                dribble = 50
            else:
                dribble = int(dribble)
            pass_ball = soup2.find('div', class_='item item4').find('span').text.strip()
            if pass_ball == '-':
                pass_ball = 50
            else:
                pass_ball = int(pass_ball)
            shoot = soup2.find('div', class_='item item5').find('span').text.strip()
            if shoot == '-':
                shoot = 50
            else:
                shoot = int(shoot)
            cursor.execute(sql, (cn_name,age,country,club,pos,shoot,speed,power,defense,dribble,pass_ball,score))
            db.commit()
        #PNAME,PAGE,PNATION,PCLUB,PPOSITION,PSHOOT,PPACE,PSTREN,PDEFEND,PDRIB,PPASS,PMIND
        f.write(cn_name)
        f.write('\b')
        f.write(club)
        f.write('\n')
        print(cn_name,en_name,player_img,club,pos,num,country,age,birthday,height,weight,foot,score,speed,power,defense,dribble,pass_ball,shoot)
db.close()
print(i)
f.close
